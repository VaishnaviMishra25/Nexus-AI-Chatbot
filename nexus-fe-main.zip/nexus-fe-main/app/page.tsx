import { Button } from '@/components/ui/button'
import React from 'react'

function HomePage() {
  return (
    <div>
      <Button>Home</Button>
    </div>
  )
}

export default HomePage