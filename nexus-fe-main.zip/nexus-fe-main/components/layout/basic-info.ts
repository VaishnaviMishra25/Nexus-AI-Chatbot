export const basicInfo =   {
    name:'Nexus AI',
    tagline:'Nexus AI Chatbot',
    phones: ["+91 9876543210", "+91 1010101010"],
    emails: ["sample@gmail.com", "support@example.com"],
    address: "123 Sample Phase 1",
    location:'Gurugram, Haryana',
    gmap: "/",
    socialMedia: {
      facebook: "/",
      twitter: "/",
      instagram: "/",
      whatsapp: "/",
    },
    workingHours: "Mon-Fri: 9:00 AM - 6:00 PM",
    websiteURL:'nexus.in'
  }