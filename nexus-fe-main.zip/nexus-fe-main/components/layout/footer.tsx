// components/Footer.js
import {
  FacebookIcon,
  TwitterIcon,
  LinkedinIcon,
  MailIcon,
  PhoneIcon,
  MapPinIcon,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full bg-neutral-900 text-neutral-100 py-14 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-12 justify-between items-start">
        {/* Branding */}
        <div className="flex-1 mb-6">
          <span className="tracking-[0.3em] text-lg font-semibold text-neutral-300">NEXUS</span>
        </div>
        {/* Information Links */}
        <div className="flex-1">
          <h4 className="font-semibold mb-3">Information</h4>
          <ul className="space-y-2 text-sm text-neutral-400">
            <li><a href="#" className="hover:text-neutral-200">Main</a></li>
            <li><a href="#" className="hover:text-neutral-200">Features</a></li>
            <li><a href="#" className="hover:text-neutral-200">About us</a></li>
            <li><a href="#" className="hover:text-neutral-200">Certifications</a></li>
            <li><a href="#" className="hover:text-neutral-200">Contacts</a></li>
          </ul>
        </div>
        {/* Contact Section */}
        <div className="flex-1">
          <h4 className="font-semibold mb-3">Contacts</h4>
          <div className="flex items-start mb-2 text-sm text-neutral-400">
            <MapPinIcon size={16} className="mr-2 mt-1" />
            <span>
              1234 Sample Street<br />
              Austin Texas 78704
            </span>
          </div>
          <div className="flex items-center mb-2 text-sm text-neutral-400">
            <PhoneIcon size={16} className="mr-2" />
            <span>512.333.2222</span>
          </div>
          <div className="flex items-center text-sm text-neutral-400">
            <MailIcon size={16} className="mr-2" />
            <span>sampleemail@gmail.com</span>
          </div>
        </div>
        {/* Social Media */}
        <div className="flex-1">
          <h4 className="font-semibold mb-3">Social Media</h4>
          <div className="flex items-center space-x-5">
            <a href="#" className="hover:text-white"><FacebookIcon size={18} /></a>
            <a href="#" className="hover:text-white"><TwitterIcon size={18} /></a>
            <a href="#" className="hover:text-white"><LinkedinIcon size={18} /></a>
          
          </div>
        </div>
      </div>
      <div className="border-t border-neutral-800 mt-12 pt-6 text-xs text-neutral-500 text-center">
        © 2019 All Rights Reserved.
      </div>
    </footer>
  );
}
