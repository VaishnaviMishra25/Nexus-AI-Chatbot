export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/features", label: "Features" },
  { href: "/certifications", label: "Certifications" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];


export const quickLinks = [
  {
    label: "FAQ",
    href: "/faq",
  },
  { href: "/contact", label: "Contact Us" },
    {
    label: "List Space",
    href: "/profile/spaces",
  },
  {
    label: "Privacy Policy",
    href: "/privacy-policy",
  },

];
